<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Robotic_kit;

class Robotic_kitSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Robotic_kit::create([
            "id" => '1',
			"name" => 'StarterKit',
			"description" => 'Introduction to Robotics',
			"created_at" => date("Y-m-d H:i:s"),
			"updated_at" => date("Y-m-d H:i:s"),
		]);

        Robotic_kit::create([
            "id" => '2',
			"name" => 'Educational Robotics Kit',
			"description" => 'Programming for Robotics',
			"created_at" => date("Y-m-d H:i:s"),
			"updated_at" => date("Y-m-d H:i:s"),
		]);

        Robotic_kit::create([
            "id" => '3',
			"name" => 'Kit5',
			"description" => 'Characteristics of a Robot',
			"created_at" => date("Y-m-d H:i:s"),
			"updated_at" => date("Y-m-d H:i:s"),
		]);
    }
}
