<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Role;
use App\Models\User;

class UserSeeder extends Seeder
{
	/**
	 * Run the database seeds.
	 *
	 * @return void
	 */
	public function run()
	{
		User::create([
			"name" => 'Admon',
			"paternal_surname" => 'Paternal',
			"maternal_surname" => 'Maternal',
			"email" => 'admon@robotics.com',
			"password" => 'Adm@2022',
			"role_id" => 1,
			"created_at" => date("Y-m-d H:i:s"),
			"updated_at" => date("Y-m-d H:i:s"),
		]);
		User::create([
			"name" => 'Tecmilenio',
			"paternal_surname" => 'Paternal',
			"maternal_surname" => 'Maternal',
			"email" => 'tecmilenio@robotics.com',
			"password" => 'Adm@2022',
			"role_id" => 1,
			"created_at" => date("Y-m-d H:i:s"),
			"updated_at" => date("Y-m-d H:i:s"),
		]);

		User::create([
			"name" => 'Estudiante',
			"paternal_surname" => 'Paternal',
			"maternal_surname" => 'Maternal',
			"email" => 'estudiante@robotics.com',
			"password" => 'Adm@2022',
			"role_id" => 1,
			"created_at" => date("Y-m-d H:i:s"),
			"updated_at" => date("Y-m-d H:i:s"),
		]);
	}
}
