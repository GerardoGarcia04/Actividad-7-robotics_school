<?php

namespace Database\Factories;
use Illuminate\Database\Eloquent\Factories\Factory;
use Illuminate\Support\Str;
/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Course>
 */
class CourseFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition()
    {
        $attributes = [
            'title' => $this->faker->sentence(4),
            'front_page' => $this->faker->imageUrl(640, 480),
            'content' => $this->faker->sentence(10),
            'educational_material_id' => Str::random(10),
            'robotic_kit_id' => Str::random(10),
        ];

        return $attributes;
    }
}
