<?php
return [
	//Titles
	"title_index" => "robotic_kits",
	"title_add" => "Agregar robotic_kit",
	"title_show" => "Ver robotic_kit",
	"title_edit" => "Modificar robotic_kit",
	"title_delete" => "Eliminar robotic_kit",

	//Fields
	"id" => "id",
	"name" => "Nombre",
	"description" => "Descripción",
	"created_at" => "Fecha creado",
	"updated_at" => "Fecha modificado",

	//Action messages
	"confirm_delete" => "Se borrará robotic_kit de la base de datos. ¿Desea continuar?",
	"Successfully created" => "robotic_kit creado correctamente",
	"Successfully updated" => "robotic_kit modificado correctamente",
	"Successfully deleted" => "robotic_kit eliminado correctamente",
	"delete_error_message" => "Error al intentar eliminar robotic_kit de la base de datos",
	"delete_error_message_constraint" => "No se puede eliminar robotic_kit, hay tablas que dependen de este",
];