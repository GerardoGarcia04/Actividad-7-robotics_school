<?php
return [
	//Titles
	"title_index" => "students",
	"title_add" => "Agregar student",
	"title_show" => "Ver student",
	"title_edit" => "Modificar student",
	"title_delete" => "Eliminar student",

	//Fields
	"id" => "id",
	"name" => "Nombre",
	"email" => "email",
	"email_verified_at" => "email_verified_at",
	"password" => "password",
	"remember_token" => "remember_token",
	"group_id" => "group_id",
	"created_at" => "Fecha creado",
	"updated_at" => "Fecha modificado",

	//Action messages
	"confirm_delete" => "Se borrará student de la base de datos. ¿Desea continuar?",
	"Successfully created" => "student creado correctamente",
	"Successfully updated" => "student modificado correctamente",
	"Successfully deleted" => "student eliminado correctamente",
	"delete_error_message" => "Error al intentar eliminar student de la base de datos",
	"delete_error_message_constraint" => "No se puede eliminar student, hay tablas que dependen de este",
];