<?php
return [
	//Titles
	"title_index" => "groups",
	"title_add" => "Agregar group",
	"title_show" => "Ver group",
	"title_edit" => "Modificar group",
	"title_delete" => "Eliminar group",

	//Fields
	"id" => "id",
	"name" => "Nombre",
	"created_at" => "Fecha creado",
	"updated_at" => "Fecha modificado",

	//Action messages
	"confirm_delete" => "Se borrará group de la base de datos. ¿Desea continuar?",
	"Successfully created" => "group creado correctamente",
	"Successfully updated" => "group modificado correctamente",
	"Successfully deleted" => "group eliminado correctamente",
	"delete_error_message" => "Error al intentar eliminar group de la base de datos",
	"delete_error_message_constraint" => "No se puede eliminar group, hay tablas que dependen de este",
];