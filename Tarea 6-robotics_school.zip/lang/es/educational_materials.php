<?php
return [
	//Titles
	"title_index" => "educational_materials",
	"title_add" => "Agregar educational_material",
	"title_show" => "Ver educational_material",
	"title_edit" => "Modificar educational_material",
	"title_delete" => "Eliminar educational_material",

	//Fields
	"id" => "id",
	"name" => "Nombre",
	"type" => "type",
	"created_at" => "Fecha creado",
	"updated_at" => "Fecha modificado",

	//Action messages
	"confirm_delete" => "Se borrará educational_material de la base de datos. ¿Desea continuar?",
	"Successfully created" => "educational_material creado correctamente",
	"Successfully updated" => "educational_material modificado correctamente",
	"Successfully deleted" => "educational_material eliminado correctamente",
	"delete_error_message" => "Error al intentar eliminar educational_material de la base de datos",
	"delete_error_message_constraint" => "No se puede eliminar educational_material, hay tablas que dependen de este",
];