<?php
return [
	//Titles
	"title_index" => "courses",
	"title_add" => "Agregar course",
	"title_show" => "Ver course",
	"title_edit" => "Modificar course",
	"title_delete" => "Eliminar course",

	//Fields
	"id" => "id",
	"title" => "title",
	"front_page" => "front_page",
	"content" => "content",
	"educational_material_id" => "educational_material_id",
	"robotic_kit_id" => "robotic_kit_id",
	"created_at" => "Fecha creado",
	"updated_at" => "Fecha modificado",

	//Action messages
	"confirm_delete" => "Se borrará course de la base de datos. ¿Desea continuar?",
	"Successfully created" => "course creado correctamente",
	"Successfully updated" => "course modificado correctamente",
	"Successfully deleted" => "course eliminado correctamente",
	"delete_error_message" => "Error al intentar eliminar course de la base de datos",
	"delete_error_message_constraint" => "No se puede eliminar course, hay tablas que dependen de este",
];