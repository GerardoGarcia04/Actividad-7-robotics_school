<?php

namespace App\DataTables;

use App\Models\Educational_material;
use Yajra\DataTables\Html\Button;
use Yajra\DataTables\Html\Column;
use Yajra\DataTables\Html\Editor\Editor;
use Yajra\DataTables\Html\Editor\Fields;
use Yajra\DataTables\Services\DataTable;

class Educational_materialDataTable extends BlankDataTable
{
	public function __construct()
	{
		$this->routeResource = 'educational_materials';
	}
	/**
	 * Get query source of dataTable.
	 *
	 * @param \App\Selling $model
	 * @return \Illuminate\Database\Eloquent\Builder
	 */
	public function query(Educational_material $model)
	{
		return $model
		->newQuery();
	}

	/**
	 * Get columns.
	 *
	 * @return array
	 */
	protected function getColumns()
	{
		$pColumns = parent::getColumns();
		$columns = [
			['data' => 'id', 'visible' => false, 'title' => __('educational_materials.id')],
			['data' => 'name', 'title' => __('educational_materials.name')],
			['data' => 'type', 'title' => __('educational_materials.type')],
			['data' => 'created_at', 'visible' => false, 'title' => __('educational_materials.created_at')],
			['data' => 'updated_at', 'visible' => false, 'title' => __('educational_materials.updated_at')],
		];
		return array_merge($columns, $pColumns);
	}
}
