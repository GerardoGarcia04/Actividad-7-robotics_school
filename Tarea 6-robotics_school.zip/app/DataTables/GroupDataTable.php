<?php

namespace App\DataTables;

use App\Models\Group;
use Yajra\DataTables\Html\Button;
use Yajra\DataTables\Html\Column;
use Yajra\DataTables\Html\Editor\Editor;
use Yajra\DataTables\Html\Editor\Fields;
use Yajra\DataTables\Services\DataTable;

class GroupDataTable extends BlankDataTable
{
	public function __construct()
	{
		$this->routeResource = 'groups';
	}
	/**
	 * Get query source of dataTable.
	 *
	 * @param \App\Selling $model
	 * @return \Illuminate\Database\Eloquent\Builder
	 */
	public function query(Group $model)
	{
		return $model
		->newQuery();
	}

	/**
	 * Get columns.
	 *
	 * @return array
	 */
	protected function getColumns()
	{
		$pColumns = parent::getColumns();
		$columns = [
			['data' => 'id', 'visible' => false, 'title' => __('groups.id')],
			['data' => 'name', 'title' => __('groups.name')],
			['data' => 'created_at', 'visible' => false, 'title' => __('groups.created_at')],
			['data' => 'updated_at', 'visible' => false, 'title' => __('groups.updated_at')],
		];
		return array_merge($columns, $pColumns);
	}
}
