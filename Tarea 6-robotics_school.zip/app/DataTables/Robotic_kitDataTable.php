<?php

namespace App\DataTables;

use App\Models\Robotic_kit;
use Yajra\DataTables\Html\Button;
use Yajra\DataTables\Html\Column;
use Yajra\DataTables\Html\Editor\Editor;
use Yajra\DataTables\Html\Editor\Fields;
use Yajra\DataTables\Services\DataTable;

class Robotic_kitDataTable extends BlankDataTable
{
	public function __construct()
	{
		$this->routeResource = 'robotic_kits';
	}
	/**
	 * Get query source of dataTable.
	 *
	 * @param \App\Selling $model
	 * @return \Illuminate\Database\Eloquent\Builder
	 */
	public function query(Robotic_kit $model)
	{
		return $model
		->newQuery();
	}

	/**
	 * Get columns.
	 *
	 * @return array
	 */
	protected function getColumns()
	{
		$pColumns = parent::getColumns();
		$columns = [
			['data' => 'id', 'visible' => false, 'title' => __('robotic_kits.id')],
			['data' => 'name', 'title' => __('robotic_kits.name')],
			['data' => 'description', 'title' => __('robotic_kits.description')],
			['data' => 'created_at', 'visible' => false, 'title' => __('robotic_kits.created_at')],
			['data' => 'updated_at', 'visible' => false, 'title' => __('robotic_kits.updated_at')],
		];
		return array_merge($columns, $pColumns);
	}
}
