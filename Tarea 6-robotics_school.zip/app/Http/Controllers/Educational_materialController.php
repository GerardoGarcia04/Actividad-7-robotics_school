<?php

namespace App\Http\Controllers;

use App\Models\Educational_material;

use App\Http\Requests\Educational_materialRequest;
use App\DataTables\Educational_materialDataTable;
use Illuminate\Http\Request;

class Educational_materialController extends Controller
{
	/**
	 * Display a listing of the resource.
	 *
	 * @return \Illuminate\Http\Response
	 */
	public function index()
	{
		//Consultar permiso para botón de agregar
		$allowAdd = auth()->user()->hasPermissions("educational_materials.create");
		$allowEdit = auth()->user()->hasPermissions("educational_materials.edit");
		return (new Educational_materialDataTable())->render('educational-materials.index', compact('allowAdd', 'allowEdit'));
	}

	/**
	 * Show the form for creating a new resource.
	 *
	 * @return \Illuminate\Http\Response
	 */
	public function create()
	{
		return view('educational-materials.create');
	}

	/**
	 * Store a newly created resource in storage.
	 *
	 * @param  \Illuminate\Http\Request  $request
	 * @return \Illuminate\Http\Response
	 */
	public function store(Educational_materialRequest $request)
	{
		$status = true;
		$educational_material = null;
		$params = array_merge($request->all(), [
			'created_by' => auth()->id(),
			'updated_by' => auth()->id(),
			'created_at' => date("Y-m-d H:i:s"),
			'updated_at' => date("Y-m-d H:i:s")
		]);
		try {
			$educational_material = Educational_material::create($params);
			$message = __('educational_materials.Successfully created');
		} catch (\Illuminate\Database\QueryException $e) {
			$status = false;
			$message = $this->getErrorMessage($e, 'educational_materials');
		}
		return $this->getResponse($status, $message, $educational_material);
	}

	/**
	 * Display the specified resource.
	 *
	 * @param  \App\Educational_material  $educational_material
	 * @return \Illuminate\Http\Response
	 */
	public function show(Educational_material $educational_material)
	{
		return view('educational-materials.show', compact('educational_material'));
	}

	/**
	 * Show the form for editing the specified resource.
	 *
	 * @param  \App\Educational_material  $educational_material
	 * @return \Illuminate\Http\Response
	 */
	public function edit(Educational_material $educational_material)
	{
		return view('educational-materials.edit', compact('educational_material'));
	}

	/**
	 * Update the specified resource in storage.
	 *
	 * @param  \Illuminate\Http\Request  $request
	 * @param  \App\Educational_material  $educational_material
	 * @return \Illuminate\Http\Response
	 */
	public function update(Educational_materialRequest $request, Educational_material $educational_material)
	{
		$status = true;
		$params = array_merge($request->all(), [
			'updated_by' => auth()->id(),
			'updated_at' => date("Y-m-d H:i:s")
		]);
		try {
			$educational_material->update($params);
			$message = __('educational_materials.Successfully updated');
		} catch (\Illuminate\Database\QueryException $e) {
			$status = false;
			$message = $this->getErrorMessage($e, 'educational_materials');
		}
		return $this->getResponse($status, $message, $educational_material);
	}

	/**
	 * Remove the specified resource from storage.
	 *
	 * @param  \App\Educational_material  $educational_material
	 * @return \Illuminate\Http\Response
	 */
	public function destroy(Educational_material $educational_material)
	{
		$status = true;
		try {
			$educational_material->delete();
			$message = __('educational_materials.Successfully deleted');
		} catch (\Illuminate\Database\QueryException $e) {
			$status = false;
			$message = $this->getErrorMessage($e, 'educational_materials');
		}
		return $this->getResponse($status, $message);
	}

	public function getQuickModalContent(Educational_material $educational_material = null)
	{
		$params = request("params");
		return response()->json(view('crud-maker.components.modal-quickadd', compact('params', 'educational_material'))->render());
	}
}
