<?php

namespace App\Http\Controllers;

use App\Models\Student;

use App\Http\Requests\StudentRequest;
use App\DataTables\StudentDataTable;
use Illuminate\Http\Request;

class StudentController extends Controller
{
	/**
	 * Display a listing of the resource.
	 *
	 * @return \Illuminate\Http\Response
	 */
	public function index()
	{
		//Consultar permiso para botón de agregar
		$allowAdd = auth()->user()->hasPermissions("students.create");
		$allowEdit = auth()->user()->hasPermissions("students.edit");
		return (new StudentDataTable())->render('students.index', compact('allowAdd', 'allowEdit'));
	}

	/**
	 * Show the form for creating a new resource.
	 *
	 * @return \Illuminate\Http\Response
	 */
	public function create()
	{
		return view('students.create');
	}

	/**
	 * Store a newly created resource in storage.
	 *
	 * @param  \Illuminate\Http\Request  $request
	 * @return \Illuminate\Http\Response
	 */
	public function store(StudentRequest $request)
	{
		$status = true;
		$student = null;
		$params = array_merge($request->all(), [
			'created_by' => auth()->id(),
			'updated_by' => auth()->id(),
			'created_at' => date("Y-m-d H:i:s"),
			'updated_at' => date("Y-m-d H:i:s")
		]);
		try {
			$student = Student::create($params);
			$message = __('students.Successfully created');
		} catch (\Illuminate\Database\QueryException $e) {
			$status = false;
			$message = $this->getErrorMessage($e, 'students');
		}
		return $this->getResponse($status, $message, $student);
	}

	/**
	 * Display the specified resource.
	 *
	 * @param  \App\Student  $student
	 * @return \Illuminate\Http\Response
	 */
	public function show(Student $student)
	{
		return view('students.show', compact('student'));
	}

	/**
	 * Show the form for editing the specified resource.
	 *
	 * @param  \App\Student  $student
	 * @return \Illuminate\Http\Response
	 */
	public function edit(Student $student)
	{
		return view('students.edit', compact('student'));
	}

	/**
	 * Update the specified resource in storage.
	 *
	 * @param  \Illuminate\Http\Request  $request
	 * @param  \App\Student  $student
	 * @return \Illuminate\Http\Response
	 */
	public function update(StudentRequest $request, Student $student)
	{
		$status = true;
		$params = array_merge($request->all(), [
			'updated_by' => auth()->id(),
			'updated_at' => date("Y-m-d H:i:s")
		]);
		try {
			$student->update($params);
			$message = __('students.Successfully updated');
		} catch (\Illuminate\Database\QueryException $e) {
			$status = false;
			$message = $this->getErrorMessage($e, 'students');
		}
		return $this->getResponse($status, $message, $student);
	}

	/**
	 * Remove the specified resource from storage.
	 *
	 * @param  \App\Student  $student
	 * @return \Illuminate\Http\Response
	 */
	public function destroy(Student $student)
	{
		$status = true;
		try {
			$student->delete();
			$message = __('students.Successfully deleted');
		} catch (\Illuminate\Database\QueryException $e) {
			$status = false;
			$message = $this->getErrorMessage($e, 'students');
		}
		return $this->getResponse($status, $message);
	}

	public function getQuickModalContent(Student $student = null)
	{
		$params = request("params");
		return response()->json(view('crud-maker.components.modal-quickadd', compact('params', 'student'))->render());
	}
}
