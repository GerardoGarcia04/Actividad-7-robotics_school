<?php

namespace App\Http\Controllers;

use App\Models\Robotic_kit;

use App\Http\Requests\Robotic_kitRequest;
use App\DataTables\Robotic_kitDataTable;
use Illuminate\Http\Request;

class Robotic_kitController extends Controller
{
	/**
	 * Display a listing of the resource.
	 *
	 * @return \Illuminate\Http\Response
	 */
	public function index()
	{
		//Consultar permiso para botón de agregar
		$allowAdd = auth()->user()->hasPermissions("robotic_kits.create");
		$allowEdit = auth()->user()->hasPermissions("robotic_kits.edit");
		return (new Robotic_kitDataTable())->render('robotic-kits.index', compact('allowAdd', 'allowEdit'));
	}

	/**
	 * Show the form for creating a new resource.
	 *
	 * @return \Illuminate\Http\Response
	 */
	public function create()
	{
		return view('robotic-kits.create');
	}

	/**
	 * Store a newly created resource in storage.
	 *
	 * @param  \Illuminate\Http\Request  $request
	 * @return \Illuminate\Http\Response
	 */
	public function store(Robotic_kitRequest $request)
	{
		$status = true;
		$robotic_kit = null;
		$params = array_merge($request->all(), [
			'created_by' => auth()->id(),
			'updated_by' => auth()->id(),
			'created_at' => date("Y-m-d H:i:s"),
			'updated_at' => date("Y-m-d H:i:s")
		]);
		try {
			$robotic_kit = Robotic_kit::create($params);
			$message = __('robotic_kits.Successfully created');
		} catch (\Illuminate\Database\QueryException $e) {
			$status = false;
			$message = $this->getErrorMessage($e, 'robotic_kits');
		}
		return $this->getResponse($status, $message, $robotic_kit);
	}

	/**
	 * Display the specified resource.
	 *
	 * @param  \App\Robotic_kit  $robotic_kit
	 * @return \Illuminate\Http\Response
	 */
	public function show(Robotic_kit $robotic_kit)
	{
		return view('robotic-kits.show', compact('robotic_kit'));
	}

	/**
	 * Show the form for editing the specified resource.
	 *
	 * @param  \App\Robotic_kit  $robotic_kit
	 * @return \Illuminate\Http\Response
	 */
	public function edit(Robotic_kit $robotic_kit)
	{
		return view('robotic-kits.edit', compact('robotic_kit'));
	}

	/**
	 * Update the specified resource in storage.
	 *
	 * @param  \Illuminate\Http\Request  $request
	 * @param  \App\Robotic_kit  $robotic_kit
	 * @return \Illuminate\Http\Response
	 */
	public function update(Robotic_kitRequest $request, Robotic_kit $robotic_kit)
	{
		$status = true;
		$params = array_merge($request->all(), [
			'updated_by' => auth()->id(),
			'updated_at' => date("Y-m-d H:i:s")
		]);
		try {
			$robotic_kit->update($params);
			$message = __('robotic_kits.Successfully updated');
		} catch (\Illuminate\Database\QueryException $e) {
			$status = false;
			$message = $this->getErrorMessage($e, 'robotic_kits');
		}
		return $this->getResponse($status, $message, $robotic_kit);
	}

	/**
	 * Remove the specified resource from storage.
	 *
	 * @param  \App\Robotic_kit  $robotic_kit
	 * @return \Illuminate\Http\Response
	 */
	public function destroy(Robotic_kit $robotic_kit)
	{
		$status = true;
		try {
			$robotic_kit->delete();
			$message = __('robotic_kits.Successfully deleted');
		} catch (\Illuminate\Database\QueryException $e) {
			$status = false;
			$message = $this->getErrorMessage($e, 'robotic_kits');
		}
		return $this->getResponse($status, $message);
	}

	public function getQuickModalContent(Robotic_kit $robotic_kit = null)
	{
		$params = request("params");
		return response()->json(view('crud-maker.components.modal-quickadd', compact('params', 'robotic_kit'))->render());
	}
}
