<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Educational_material extends Model
{
	use HasFactory;
	
	protected $table = 'educational_materials';
	protected $fillable = ['name', 'type', 'created_at', 'updated_at'];

	
}