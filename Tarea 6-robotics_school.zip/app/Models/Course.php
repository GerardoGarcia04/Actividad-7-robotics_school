<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Course extends Model
{
	use HasFactory;
	
	protected $table = 'courses';
	protected $fillable = ['title', 'front_page', 'content', 'educational_material_id', 'robotic_kit_id', 'created_at', 'updated_at'];

	
}