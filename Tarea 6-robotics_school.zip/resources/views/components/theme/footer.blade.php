<footer class="footer">
	<div class="container-fluid">
		<div class="row">
			<div class="col-sm-6">
				{{ date('Y') }} © Copixil S.A. de C.V.
			</div>
			<div class="col-sm-6">
				<div class="text-sm-end d-none d-sm-block">
					Tema creado por Copixil
				</div>
			</div>
		</div>
	</div>
</footer>