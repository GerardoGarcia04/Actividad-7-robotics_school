@include("crud-maker.components.form-row", ["params" => [
	[
		"name" => "name",
		"id" => "name",
		"class" => "form-control",
		"entity" => "robotic_kits",
		"type" => "text",
		"defaultValue" => old("name") ?? ($robotic_kit->name ?? ""),
		"required" => "true",
	]
]])
@include("crud-maker.components.form-row", ["params" => [
	[
		"name" => "description",
		"id" => "description",
		"class" => "form-control",
		"entity" => "robotic_kits",
		"type" => "text",
		"defaultValue" => old("description") ?? ($robotic_kit->description ?? ""),
		"required" => "true",
	]
]])
