@extends('crud-maker.layouts.index', [
	'title' => __('robotic_kits.title_index'), 
	'entity' => 'robotic_kits', 
	'form' => 'robotic_kit',
])

@section('datatable')
	{{ $dataTable->table(["width" => "100%"]) }}
@endsection