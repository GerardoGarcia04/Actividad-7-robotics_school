@extends('layouts.app', [
	'title' => __('robotic_kits.title_show'), 
])

@section('content')
<div class="report-container p-3">
	<div class="row">
		<div class="col-sm-12 col-md-6 offset-md-3">
			<br>
			<div class="card card-info">
				<div class="card-header">
					<div class="row">
						<div class="col-sm-12 col-md-6 card-title">@lang('robotic_kits.title_show')</div>
						<div class="col-sm-12 col-md-6 text-right">
							<a href="{{ route('robotic_kits.index') }}">
								<i class="fas fa-long-arrow-alt-left"></i>
							</a>
						</div>
					</div>
				</div>
				<div class="card-body">
					
					<div class="row">
						<div class="col-sm-4 offset-sm-1 text-end">@lang('robotic_kits.id')</div>
						<div class="col-sm-6">{{ $robotic_kit->id }}</div>
					</div>
					<div class="row">
						<div class="col-sm-4 offset-sm-1 text-end">@lang('robotic_kits.name')</div>
						<div class="col-sm-6">{{ $robotic_kit->name }}</div>
					</div>
					<div class="row">
						<div class="col-sm-4 offset-sm-1 text-end">@lang('robotic_kits.description')</div>
						<div class="col-sm-6">{{ $robotic_kit->description }}</div>
					</div>
					<div class="row">
						<div class="col-sm-4 offset-sm-1 text-end">@lang('robotic_kits.created_at')</div>
						<div class="col-sm-6">{{ $robotic_kit->created_at }}</div>
					</div>
					<div class="row">
						<div class="col-sm-4 offset-sm-1 text-end">@lang('robotic_kits.updated_at')</div>
						<div class="col-sm-6">{{ $robotic_kit->updated_at }}</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
@endsection