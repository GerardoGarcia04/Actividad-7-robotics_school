@include("crud-maker.components.form-row", ["params" => [
	[
		"name" => "name",
		"id" => "name",
		"class" => "form-control",
		"entity" => "students",
		"type" => "text",
		"defaultValue" => old("name") ?? ($student->name ?? ""),
		"required" => "true",
	]
]])
@include("crud-maker.components.form-row", ["params" => [
	[
		"name" => "email",
		"id" => "email",
		"class" => "form-control",
		"entity" => "students",
		"type" => "text",
		"defaultValue" => old("email") ?? ($student->email ?? ""),
		"required" => "true",
	]
]])
@include("crud-maker.components.form-row", ["params" => [
	[
		"name" => "email_verified_at",
		"id" => "email_verified_at",
		"class" => "form-control",
		"entity" => "students",
		"type" => "text",
		"defaultValue" => old("email_verified_at") ?? ($student->email_verified_at ?? ""),
	]
]])
@include("crud-maker.components.form-row", ["params" => [
	[
		"name" => "password",
		"id" => "password",
		"class" => "form-control",
		"entity" => "students",
		"type" => "text",
		"defaultValue" => old("password") ?? ($student->password ?? ""),
		"required" => "true",
	]
]])
@include("crud-maker.components.form-row", ["params" => [
	[
		"name" => "remember_token",
		"id" => "remember_token",
		"class" => "form-control",
		"entity" => "students",
		"type" => "text",
		"defaultValue" => old("remember_token") ?? ($student->remember_token ?? ""),
	]
]])
@include("crud-maker.components.form-row", ["params" => [
	[
		"name" => "group_input",
		"id" => "group_input",
		"class" => "form-control input-autocomplete",
		"entity" => "students",
		"type" => "input-autocomplete",
		"defaultValue" => old("group_input") ?? ($student->group_input ?? ""),
		"required" => "true",
		"data-source" => "/getbyparam",
		"data-hidden-id" => "group_id",
		"data-hidden-value" => old("group_id") ?? ($student->group_id ?? ""),
		"translations" => "students.group_id",
	]
]])
