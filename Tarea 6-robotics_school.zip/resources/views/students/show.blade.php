@extends('layouts.app', [
	'title' => __('students.title_show'), 
])

@section('content')
<div class="report-container p-3">
	<div class="row">
		<div class="col-sm-12 col-md-6 offset-md-3">
			<br>
			<div class="card card-info">
				<div class="card-header">
					<div class="row">
						<div class="col-sm-12 col-md-6 card-title">@lang('students.title_show')</div>
						<div class="col-sm-12 col-md-6 text-right">
							<a href="{{ route('students.index') }}">
								<i class="fas fa-long-arrow-alt-left"></i>
							</a>
						</div>
					</div>
				</div>
				<div class="card-body">
					
					<div class="row">
						<div class="col-sm-4 offset-sm-1 text-end">@lang('students.id')</div>
						<div class="col-sm-6">{{ $student->id }}</div>
					</div>
					<div class="row">
						<div class="col-sm-4 offset-sm-1 text-end">@lang('students.name')</div>
						<div class="col-sm-6">{{ $student->name }}</div>
					</div>
					<div class="row">
						<div class="col-sm-4 offset-sm-1 text-end">@lang('students.email')</div>
						<div class="col-sm-6">{{ $student->email }}</div>
					</div>
					<div class="row">
						<div class="col-sm-4 offset-sm-1 text-end">@lang('students.email_verified_at')</div>
						<div class="col-sm-6">{{ $student->email_verified_at }}</div>
					</div>
					<div class="row">
						<div class="col-sm-4 offset-sm-1 text-end">@lang('students.password')</div>
						<div class="col-sm-6">{{ $student->password }}</div>
					</div>
					<div class="row">
						<div class="col-sm-4 offset-sm-1 text-end">@lang('students.remember_token')</div>
						<div class="col-sm-6">{{ $student->remember_token }}</div>
					</div>
					<div class="row">
						<div class="col-sm-4 offset-sm-1 text-end">@lang('students.group_id')</div>
						<div class="col-sm-6">{{ $student->group_id }}</div>
					</div>
					<div class="row">
						<div class="col-sm-4 offset-sm-1 text-end">@lang('students.created_at')</div>
						<div class="col-sm-6">{{ $student->created_at }}</div>
					</div>
					<div class="row">
						<div class="col-sm-4 offset-sm-1 text-end">@lang('students.updated_at')</div>
						<div class="col-sm-6">{{ $student->updated_at }}</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
@endsection