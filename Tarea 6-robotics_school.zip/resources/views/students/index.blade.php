@extends('crud-maker.layouts.index', [
	'title' => __('students.title_index'), 
	'entity' => 'students', 
	'form' => 'student',
])

@section('datatable')
	{{ $dataTable->table(["width" => "100%"]) }}
@endsection