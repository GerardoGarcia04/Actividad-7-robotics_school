@include("crud-maker.components.form-row", ["params" => [
	[
		"name" => "name",
		"id" => "name",
		"class" => "form-control",
		"entity" => "groups",
		"type" => "text",
		"defaultValue" => old("name") ?? ($group->name ?? ""),
		"required" => "true",
	]
]])
