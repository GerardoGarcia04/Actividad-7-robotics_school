@extends('crud-maker.layouts.index', [
	'title' => __('groups.title_index'), 
	'entity' => 'groups', 
	'form' => 'group',
])

@section('datatable')
	{{ $dataTable->table(["width" => "100%"]) }}
@endsection