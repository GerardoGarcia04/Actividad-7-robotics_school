@extends('layouts.app', [
	'title' => __('groups.title_show'), 
])

@section('content')
<div class="report-container p-3">
	<div class="row">
		<div class="col-sm-12 col-md-6 offset-md-3">
			<br>
			<div class="card card-info">
				<div class="card-header">
					<div class="row">
						<div class="col-sm-12 col-md-6 card-title">@lang('groups.title_show')</div>
						<div class="col-sm-12 col-md-6 text-right">
							<a href="{{ route('groups.index') }}">
								<i class="fas fa-long-arrow-alt-left"></i>
							</a>
						</div>
					</div>
				</div>
				<div class="card-body">
					
					<div class="row">
						<div class="col-sm-4 offset-sm-1 text-end">@lang('groups.id')</div>
						<div class="col-sm-6">{{ $group->id }}</div>
					</div>
					<div class="row">
						<div class="col-sm-4 offset-sm-1 text-end">@lang('groups.name')</div>
						<div class="col-sm-6">{{ $group->name }}</div>
					</div>
					<div class="row">
						<div class="col-sm-4 offset-sm-1 text-end">@lang('groups.created_at')</div>
						<div class="col-sm-6">{{ $group->created_at }}</div>
					</div>
					<div class="row">
						<div class="col-sm-4 offset-sm-1 text-end">@lang('groups.updated_at')</div>
						<div class="col-sm-6">{{ $group->updated_at }}</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
@endsection