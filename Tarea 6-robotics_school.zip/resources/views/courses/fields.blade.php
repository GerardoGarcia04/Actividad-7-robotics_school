@include("crud-maker.components.form-row", ["params" => [
	[
		"name" => "title",
		"id" => "title",
		"class" => "form-control",
		"entity" => "courses",
		"type" => "text",
		"defaultValue" => old("title") ?? ($course->title ?? ""),
		"required" => "true",
	]
]])
@include("crud-maker.components.form-row", ["params" => [
	[
		"name" => "front_page",
		"id" => "front_page",
		"class" => "form-control",
		"entity" => "courses",
		"type" => "text",
		"defaultValue" => old("front_page") ?? ($course->front_page ?? ""),
		"required" => "true",
	]
]])
@include("crud-maker.components.form-row", ["params" => [
	[
		"name" => "content",
		"id" => "content",
		"class" => "form-control",
		"entity" => "courses",
		"type" => "text",
		"defaultValue" => old("content") ?? ($course->content ?? ""),
		"required" => "true",
	]
]])
@include("crud-maker.components.form-row", ["params" => [
	[
		"name" => "educational_input",
		"id" => "educational_input",
		"class" => "form-control input-autocomplete",
		"entity" => "courses",
		"type" => "input-autocomplete",
		"defaultValue" => old("educational_input") ?? ($course->educational_input ?? ""),
		"required" => "true",
		"data-source" => "/getbyparam",
		"data-hidden-id" => "educational_material_id",
		"data-hidden-value" => old("educational_material_id") ?? ($course->educational_material_id ?? ""),
		"translations" => "courses.educational_material_id",
	]
]])
@include("crud-maker.components.form-row", ["params" => [
	[
		"name" => "robotic_input",
		"id" => "robotic_input",
		"class" => "form-control input-autocomplete",
		"entity" => "courses",
		"type" => "input-autocomplete",
		"defaultValue" => old("robotic_input") ?? ($course->robotic_input ?? ""),
		"required" => "true",
		"data-source" => "/getbyparam",
		"data-hidden-id" => "robotic_kit_id",
		"data-hidden-value" => old("robotic_kit_id") ?? ($course->robotic_kit_id ?? ""),
		"translations" => "courses.robotic_kit_id",
	]
]])
