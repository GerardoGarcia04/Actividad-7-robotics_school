@extends('layouts.app', [
	'title' => __('educational_materials.title_show'), 
])

@section('content')
<div class="report-container p-3">
	<div class="row">
		<div class="col-sm-12 col-md-6 offset-md-3">
			<br>
			<div class="card card-info">
				<div class="card-header">
					<div class="row">
						<div class="col-sm-12 col-md-6 card-title">@lang('educational_materials.title_show')</div>
						<div class="col-sm-12 col-md-6 text-right">
							<a href="{{ route('educational_materials.index') }}">
								<i class="fas fa-long-arrow-alt-left"></i>
							</a>
						</div>
					</div>
				</div>
				<div class="card-body">
					
					<div class="row">
						<div class="col-sm-4 offset-sm-1 text-end">@lang('educational_materials.id')</div>
						<div class="col-sm-6">{{ $educational_material->id }}</div>
					</div>
					<div class="row">
						<div class="col-sm-4 offset-sm-1 text-end">@lang('educational_materials.name')</div>
						<div class="col-sm-6">{{ $educational_material->name }}</div>
					</div>
					<div class="row">
						<div class="col-sm-4 offset-sm-1 text-end">@lang('educational_materials.type')</div>
						<div class="col-sm-6">{{ $educational_material->type }}</div>
					</div>
					<div class="row">
						<div class="col-sm-4 offset-sm-1 text-end">@lang('educational_materials.created_at')</div>
						<div class="col-sm-6">{{ $educational_material->created_at }}</div>
					</div>
					<div class="row">
						<div class="col-sm-4 offset-sm-1 text-end">@lang('educational_materials.updated_at')</div>
						<div class="col-sm-6">{{ $educational_material->updated_at }}</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
@endsection