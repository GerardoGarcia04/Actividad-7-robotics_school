@extends('crud-maker.layouts.index', [
	'title' => __('educational_materials.title_index'), 
	'entity' => 'educational_materials', 
	'form' => 'educational_material',
])

@section('datatable')
	{{ $dataTable->table(["width" => "100%"]) }}
@endsection