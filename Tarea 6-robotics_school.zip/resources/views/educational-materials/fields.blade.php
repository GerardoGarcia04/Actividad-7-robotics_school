@include("crud-maker.components.form-row", ["params" => [
	[
		"name" => "name",
		"id" => "name",
		"class" => "form-control",
		"entity" => "educational_materials",
		"type" => "text",
		"defaultValue" => old("name") ?? ($educational_material->name ?? ""),
		"required" => "true",
	]
]])
@include("crud-maker.components.form-row", ["params" => [
	[
		"name" => "type",
		"id" => "type",
		"class" => "form-control",
		"entity" => "educational_materials",
		"type" => "text",
		"defaultValue" => old("type") ?? ($educational_material->type ?? ""),
		"required" => "true",
	]
]])
